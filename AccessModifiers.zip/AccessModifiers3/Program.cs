﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessModifiers3
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student();
            Console.WriteLine("Name: " + student1.name);
            Employee emp = new Employee();
            //emp.Print1();
            Student2 str = new Student2();
            Console.WriteLine(str.Method1());
            Greet greet = new Greet();
            Console.WriteLine(greet.msg);
            Console.ReadLine();
        }
    }
    class Student
    {
        public string name = "Sheeran";

        public void print()
        {
            Console.WriteLine("Hello from Student class");
        }
    }
    class Employee
    {
        private string name = "Pavan";

        private void print1()
        {
            Console.WriteLine("Hello World");
        }
    }
    class Student1
    {
        protected string name = "Sai";
    }
    class Student2:Student1
    {
        public string Method1()
        {
            return name;
        }
      
    }
    public class StudentName
    {
        internal string name = "Jagadeesh";
    }
    public class Greet
    {
        protected internal string msg = "Hello";
    }



}
