﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using UserRegistration.Models;

namespace UserRegistration.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<UserRegistration.Models.RegisterViewModel>? RegisterViewModel { get; set; }
        public DbSet<UserRegistration.Models.LoginViewModel>? LoginViewModel { get; set; }
        public DbSet<UserRegistration.Models.RoleViewModel>? RoleViewModel { get; set; }
        public DbSet<UserRegistration.Models.EditViewModel>? EditViewModel { get; set; }
    }
}
