﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace UserRegistration.Models
{
    [Keyless]
    public class RegisterViewModel
    {
        
        [Required(ErrorMessage ="Email is required")]
        [EmailAddress]
        public string? Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string? Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name ="Conform Password")]
        [Compare("Password",ErrorMessage ="Password does not match")]
        public string? ConformPassword { get; set; }
    }
}
