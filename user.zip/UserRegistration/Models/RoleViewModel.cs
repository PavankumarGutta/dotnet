﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace UserRegistration.Models
{
    [Keyless]
    public class RoleViewModel
    {
        
        public int Id { get; set; } 
        [Required]
        public string? Name { get; set; }
    }
}
