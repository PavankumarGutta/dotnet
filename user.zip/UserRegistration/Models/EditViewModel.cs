﻿namespace UserRegistration.Models
{
    public class EditViewModel:RoleViewModel
    {
        public string? Id { get; set; }
        public string? RoleName { get; set; }
        public List<string> Users { get; set; }
    }
}
