﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserRegistration.Models;

namespace UserRegistration.Controllers
{
    [Authorize()]
    public class RoleController : Controller
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<IdentityUser> _userManager;    
        public RoleController(RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult CreateRole()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateRole(RoleViewModel role)
        {
            if (ModelState.IsValid)
            {
                bool isExists = await _roleManager.RoleExistsAsync(role.Name);
                if (isExists)
                {
                    ModelState.AddModelError(string.Empty, errorMessage: "role is already exists");
                }
                else
                {
                    var r = new IdentityRole { Name = role.Name };
                    var result = await _roleManager.CreateAsync(r);
                    if (result.Succeeded)
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    foreach (IdentityError error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }

                }
            }
            return View(role);

        }

        [HttpGet]
        public async Task<IActionResult> Rolelist()
        {
            var roles = await _roleManager.Roles.ToListAsync();
            return View(roles);
        }
        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            var role = await _roleManager.FindByIdAsync(id);
            
            var model=new EditViewModel {Id=role.Id,RoleName=role.Name};
            model.Users = new List<string>();
            foreach(var user in _userManager.Users.ToList())
            {
                if (await _userManager.IsInRoleAsync(user, role.Name))
                {
                    model.Users.Add(user.UserName);
                }
            }
            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult>Edit(EditViewModel model)
        {
            var role = await _roleManager.FindByIdAsync(model.Id);
            role.Name = model.RoleName;
            var result = await _roleManager.UpdateAsync(role);
            return View(result);
        }
        [HttpPost]
        public async Task<IActionResult> Delete(string id)
        {

            var role = await _roleManager.FindByIdAsync(id);
            var result= await _roleManager.DeleteAsync(role);
            return View(result);
        }

       

    }
}
