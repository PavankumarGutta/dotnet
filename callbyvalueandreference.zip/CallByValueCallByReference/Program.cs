﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallByValueCallByReference
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 20;
            int b = 30;
            Console.WriteLine($"Value a:{a}");
            UpdateValueUsingRef(ref a);
            Console.WriteLine($"Value after update a:{a}");

            Console.WriteLine($"Value a,b:{a},{b}");
            UpdateValueUsingOut(out a, out b);
            Console.WriteLine($"Value after update a,b:{a},{b}");
            Boxing();
            UnBoxing();

            Console.ReadLine();
        }
        public static void UpdateValueUsingRef(ref int a)
        {
            a = 30;
        }

        public static void UpdateValueUsingOut(out int a, out int b)
        {
            a = 50;
            b = 100;
        }
        public static void Boxing()
        {
            int a = 10;
            double d = a;
            Console.WriteLine("boxing:"+d);
        }
        public static void UnBoxing()
        {
            double c = 20.5;
            int e = (int)c;
            Console.WriteLine("Unboxing:" + e);
        }
    }
}
